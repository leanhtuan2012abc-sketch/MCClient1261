MC CLIENT 1.26.1 — DỰ ÁN ANDROID

Đây là mã nguồn dự án Android Studio, KHÔNG phải APK đã biên dịch.
Cách tạo APK:
1. Cài Android Studio trên máy tính.
2. Mở thư mục MCClient1261-Android.
3. Chờ Gradle đồng bộ (cần Internet và Android SDK Platform 35).
4. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug thường nằm tại app/build/outputs/apk/debug/app-debug.apk.

Giới hạn:
- App này là giao diện demo chạy độc lập.
- Công tắc X-Ray chỉ minh họa danh sách quặng; không thể nhìn xuyên khối trong Minecraft.
- KillAura chỉ mô phỏng chọn mob trong app; không điều khiển Minecraft và không tự động tấn công.
- Không có quyền truy cập bộ nhớ Minecraft, không có overlay tương tác với game.
